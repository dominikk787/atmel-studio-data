/*
 * $safeprojectname$.c
 *
 * Created: 2019-06-09 15:09:15
 * Author : programowanie
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

